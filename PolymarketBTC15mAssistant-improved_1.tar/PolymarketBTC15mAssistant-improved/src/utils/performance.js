/**
 * Performance tracking for predictions
 * Enhanced for GitHub Codespaces with multiple persistence options
 */
import fs from 'node:fs';
import path from 'node:path';

class PerformanceTracker {
  constructor() {
    this.predictions = [];
    
    // Try multiple storage locations
    this.storagePaths = this.detectStoragePaths();
    this.logPath = this.storagePaths.primary;
    
    this.loadFromFile();
    this.displayStorageInfo();
  }

  detectStoragePaths() {
    const paths = {
      primary: null,
      alternatives: []
    };

    // 1. Try workspace persistent storage (Codespaces)
    if (process.env.CODESPACE_NAME) {
      const workspaceDir = '/workspaces';
      if (fs.existsSync(workspaceDir)) {
        paths.primary = path.join(workspaceDir, '.polymarket-logs', 'performance.json');
        paths.alternatives.push(paths.primary);
      }
    }

    // 2. Try home directory (persists in Codespaces)
    const homeDir = process.env.HOME || process.env.USERPROFILE;
    if (homeDir) {
      const homePath = path.join(homeDir, '.polymarket', 'performance.json');
      if (!paths.primary) paths.primary = homePath;
      paths.alternatives.push(homePath);
    }

    // 3. Fallback to local logs (ephemeral in Codespaces)
    const localPath = './logs/performance.json';
    if (!paths.primary) paths.primary = localPath;
    paths.alternatives.push(localPath);

    return paths;
  }

  displayStorageInfo() {
    const isCodespaces = !!process.env.CODESPACE_NAME;
    const isPersistent = this.logPath.includes('/workspaces') || this.logPath.includes(process.env.HOME);
    
    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📊 PERFORMANCE TRACKING');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`Environment: ${isCodespaces ? 'GitHub Codespaces' : 'Local'}`);
    console.log(`Storage: ${this.logPath}`);
    console.log(`Persistent: ${isPersistent ? '✅ YES' : '⚠️  NO (ephemeral)'}`);
    
    if (isCodespaces && !isPersistent) {
      console.log('\n⚠️  WARNING: Logs will be lost when Codespace stops!');
      console.log('💡 TIP: Copy logs/performance.json to your repo to preserve data');
    }
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  }

  recordPrediction({ marketSlug, predictedDirection, priceToBeat, currentPrice, timestamp, modelProb }) {
    const prediction = {
      marketSlug,
      predictedDirection,
      priceToBeat,
      entryPrice: currentPrice,
      entryTime: timestamp,
      modelProb,
      settled: false,
      correct: null,
      finalPrice: null,
      settlementTime: null
    };
    
    this.predictions.push(prediction);
    this.saveToFile();
    
    // Also log to console for Codespaces users
    console.log(`\n📝 PREDICTION RECORDED: ${predictedDirection} (${(modelProb * 100).toFixed(1)}%)`);
    console.log(`   Market: ${marketSlug}`);
    console.log(`   Price to Beat: $${priceToBeat.toFixed(2)}`);
    console.log(`   Entry Price: $${currentPrice.toFixed(2)}\n`);
  }

  recordSettlement({ marketSlug, finalPrice, timestamp }) {
    const pred = this.predictions.find(p => p.marketSlug === marketSlug && !p.settled);
    if (!pred) return;
    
    pred.settled = true;
    pred.settlementTime = timestamp;
    pred.finalPrice = finalPrice;
    pred.correct = (pred.predictedDirection === 'UP' && finalPrice > pred.priceToBeat) ||
                   (pred.predictedDirection === 'DOWN' && finalPrice < pred.priceToBeat);
    
    this.saveToFile();
    
    // Log result to console
    const result = pred.correct ? '✅ CORRECT' : '❌ INCORRECT';
    const stats = this.getStats();
    
    console.log(`\n🏁 SETTLEMENT: ${result}`);
    console.log(`   Predicted: ${pred.predictedDirection}`);
    console.log(`   Price to Beat: $${pred.priceToBeat.toFixed(2)}`);
    console.log(`   Final Price: $${finalPrice.toFixed(2)}`);
    console.log(`   Overall Accuracy: ${stats.accuracy}% (${stats.correct}/${stats.total})\n`);
  }

  getStats() {
    const settled = this.predictions.filter(p => p.settled);
    const correct = settled.filter(p => p.correct).length;
    const last10 = settled.slice(-10);
    const last10Correct = last10.filter(p => p.correct).length;
    
    return {
      total: settled.length,
      correct,
      accuracy: settled.length > 0 ? (correct / settled.length * 100).toFixed(1) : 0,
      last10Accuracy: last10.length > 0 ? (last10Correct / last10.length * 100).toFixed(1) : 0,
      pending: this.predictions.filter(p => !p.settled).length
    };
  }

  saveToFile() {
    // Try all storage paths
    let saved = false;
    
    for (const storagePath of this.storagePaths.alternatives) {
      try {
        fs.mkdirSync(path.dirname(storagePath), { recursive: true });
        fs.writeFileSync(storagePath, JSON.stringify(this.predictions, null, 2), 'utf8');
        saved = true;
        // Only show message if not using primary path
        if (storagePath !== this.logPath) {
          console.log(`[PerformanceTracker] Also saved to: ${storagePath}`);
        }
      } catch (err) {
        // Silently continue to next path
      }
    }
    
    if (!saved) {
      console.error('[PerformanceTracker] Failed to save to any location');
    }
  }

  loadFromFile() {
    // Try all storage paths, use first one that exists
    for (const storagePath of this.storagePaths.alternatives) {
      try {
        if (fs.existsSync(storagePath)) {
          const data = fs.readFileSync(storagePath, 'utf8');
          this.predictions = JSON.parse(data);
          console.log(`[PerformanceTracker] Loaded ${this.predictions.length} predictions from ${storagePath}`);
          return;
        }
      } catch (err) {
        // Continue to next path
      }
    }
    
    // No existing data found
    this.predictions = [];
  }

  // Export data as string for manual backup
  exportData() {
    return JSON.stringify(this.predictions, null, 2);
  }

  // Display summary for Codespaces users
  displaySummary() {
    const stats = this.getStats();
    
    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📊 PERFORMANCE SUMMARY');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`Total Predictions: ${stats.total}`);
    console.log(`Correct: ${stats.correct}`);
    console.log(`Accuracy: ${stats.accuracy}%`);
    console.log(`Last 10: ${stats.last10Accuracy}%`);
    console.log(`Pending: ${stats.pending}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  }
}

export const performanceTracker = new PerformanceTracker();
